param_file_path="/Users/dgrin/Desktop/axionCAMB-master/inifiles/params.ini "
axion_camb_path="/Users/dgrin/Desktop/axionCAMB-master/camb"

cosmo_database="/Users/dgrin/Desktop/axion_kSZ_source/CAMB_outputs/cosmo_db_final.dat"

camb_outputs_path="/Users/dgrin/Desktop/axion_kSZ_source/CAMB_outputs/final_out/"
